# ═══════════════════════════════════════════════════════════════
# GOEIC OFFLINE SETUP GUIDE
# Complete Migration from OpenAI/Google to Local Models
# ═══════════════════════════════════════════════════════════════

## 📋 PREREQUISITES

### Hardware Requirements (Your Server):
- ✅ CPU: Intel Xeon E5-1650 v4 (6 cores / 12 threads)
- ✅ RAM: 30 GB
- ✅ GPU: RTX 4070 Ti SUPER with 16 GB VRAM
- ✅ Storage: 100+ GB free space

### Software Requirements:
- Ubuntu 22.04 / 24.04 (recommended)
- Python 3.10+
- Docker & Docker Compose
- CUDA 12.1+ (for GPU support)
- Ollama

---

## 🚀 STEP-BY-STEP SETUP

### 1. INSTALL SYSTEM DEPENDENCIES

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and essentials
sudo apt install -y python3.10 python3-pip python3-venv
sudo apt install -y build-essential git wget curl

# Install CUDA (if not already installed)
# Visit: https://developer.nvidia.com/cuda-downloads
# Or use:
wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-ubuntu2204.pin
sudo mv cuda-ubuntu2204.pin /etc/apt/preferences.d/cuda-repository-pin-600
wget https://developer.download.nvidia.com/compute/cuda/12.6.0/local_installers/cuda-repo-ubuntu2204-12-6-local_12.6.0-560.28.03-1_amd64.deb
sudo dpkg -i cuda-repo-ubuntu2204-12-6-local_12.6.0-560.28.03-1_amd64.deb
sudo cp /var/cuda-repo-ubuntu2204-12-6-local/cuda-*-keyring.gpg /usr/share/keyrings/
sudo apt-get update
sudo apt-get -y install cuda-toolkit-12-6

# Verify CUDA
nvidia-smi
```

---

### 2. INSTALL OLLAMA (Local LLM Server)

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh

# Start Ollama service
ollama serve &

# Pull recommended model (Qwen 2.5 14B - BEST for your GPU)
ollama pull qwen2.5:14b

# Alternative models:
# ollama pull qwen2.5:7b      # Faster, still good quality
# ollama pull llama3.1:8b     # Alternative option

# Verify installation
ollama list
```

**Why Qwen 2.5 14B?**
- Fits perfectly in 16GB VRAM
- Excellent multilingual support (Arabic, English, French)
- Strong instruction following
- Good JSON output
- Fast inference on RTX 4070 Ti SUPER

---

### 3. INSTALL DOCKER & WEAVIATE

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo apt install docker-compose -y

# Create Weaviate directory
mkdir -p ~/goeic_rag/weaviate_data

# Create docker-compose.yml for Weaviate
cat > ~/goeic_rag/docker-compose.yml << 'EOF'
version: '3.4'
services:
  weaviate:
    image: semitechnologies/weaviate:1.27.0
    ports:
      - "8080:8080"
      - "50051:50051"
    environment:
      QUERY_DEFAULTS_LIMIT: 25
      AUTHENTICATION_ANONYMOUS_ACCESS_ENABLED: 'true'
      PERSISTENCE_DATA_PATH: '/var/lib/weaviate'
      DEFAULT_VECTORIZER_MODULE: 'none'
      ENABLE_MODULES: ''
      CLUSTER_HOSTNAME: 'node1'
    volumes:
      - ./weaviate_data:/var/lib/weaviate
    restart: unless-stopped
EOF

# Start Weaviate
cd ~/goeic_rag
docker-compose up -d

# Verify Weaviate
curl http://localhost:8080/v1/meta
```

---

### 4. SETUP PYTHON PROJECT

```bash
# Create project directory
mkdir -p ~/goeic_rag
cd ~/goeic_rag

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements_offline.txt

# Install PyTorch with CUDA support (if not auto-detected)
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# Verify GPU is detected
python3 << EOF
import torch
print(f"CUDA Available: {torch.cuda.is_available()}")
print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'None'}")
EOF
```

---

### 5. CONFIGURE ENVIRONMENT

```bash
# Copy environment template
cp .env.example .env

# Edit .env file
nano .env
```

**Recommended .env settings for your server:**
```bash
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5:14b
OLLAMA_TIMEOUT=180
EMBEDDING_MODEL=paraphrase-multilingual-MiniLM-L12-v2
WHISPER_MODEL_SIZE=base
WEAVIATE_HOST=localhost
```

---

### 6. PREPARE YOUR DATA

#### Option A: Fresh Scraping (Recommended)

```bash
# Run web scraper with local embeddings
python3 offline_web_scraper.py

# This will:
# - Scrape GOEIC website (all 3 languages)
# - Generate embeddings locally (no API calls)
# - Index into Weaviate
# - Takes ~2-4 hours for 6000 pages
```

#### Option B: Re-index Existing Data

```bash
# If you have clean_data.json from old system
python3 indexer_local.py

# If you have Excel + PDF files
python3 offline_excel_pdf_ingest.py
```

---

### 7. TEST THE SYSTEM

```bash
# Start the application
python3 main_offline.py

# In another terminal, test health endpoint
curl http://localhost:8000/health

# Test chat endpoint
curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "question": "ما هي الوظائف المتاحة؟",
    "language": "ar"
  }'
```

---

### 8. PERFORMANCE TUNING

#### GPU Memory Optimization

Edit `.env` to adjust based on GPU load:

```bash
# For 16GB VRAM (your setup):
OLLAMA_MODEL=qwen2.5:14b  # Uses ~10-12GB, leaves room for embeddings

# If you get OOM errors, reduce to:
OLLAMA_MODEL=qwen2.5:7b   # Uses ~5-7GB
```

#### Concurrent Request Handling

In `main_offline.py`, adjust:
```python
# Line 108: Increase for more concurrent users
limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)

# Line 656: Adjust context window
"num_ctx": 8192,  # Increase to 16384 for longer documents
```

#### Embeddings Acceleration

The sentence-transformers model automatically uses GPU. Verify:
```python
python3 << EOF
from sentence_transformers import SentenceTransformer
import torch
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
print(f"Device: {model.device}")  # Should show 'cuda'
EOF
```

---

### 9. PRODUCTION DEPLOYMENT

#### Using systemd (Recommended)

```bash
# Create service file
sudo nano /etc/systemd/system/goeic-rag.service
```

```ini
[Unit]
Description=GOEIC RAG Offline Service
After=network.target docker.service

[Service]
Type=simple
User=your_username
WorkingDirectory=/home/your_username/goeic_rag
Environment="PATH=/home/your_username/goeic_rag/venv/bin"
ExecStart=/home/your_username/goeic_rag/venv/bin/python3 main_offline.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start service
sudo systemctl daemon-reload
sudo systemctl enable goeic-rag
sudo systemctl start goeic-rag

# Check status
sudo systemctl status goeic-rag

# View logs
sudo journalctl -u goeic-rag -f
```

#### Using Nginx Reverse Proxy

```bash
# Install Nginx
sudo apt install nginx -y

# Create config
sudo nano /etc/nginx/sites-available/goeic-rag
```

```nginx
server {
    listen 80;
    server_name your_domain.com;

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/goeic-rag /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## 🎯 EXPECTED PERFORMANCE

### Response Times (on your server):

| Task | Expected Time |
|------|--------------|
| Simple query | 2-4 seconds |
| Complex query (with context) | 4-8 seconds |
| Voice transcription | 1-2 seconds |
| TTS generation | 2-3 seconds |
| Embedding generation | 0.1-0.3 seconds |

### Model Comparison:

| Model | VRAM | Speed | Quality |
|-------|------|-------|---------|
| Qwen 2.5 14B | ~12GB | Good | Excellent ⭐ |
| Qwen 2.5 7B | ~6GB | Fast | Very Good |
| Llama 3.1 8B | ~7GB | Fast | Good |

---

## 🔧 TROUBLESHOOTING

### Issue: Ollama not responding

```bash
# Check if Ollama is running
ps aux | grep ollama

# Restart Ollama
pkill ollama
ollama serve &

# Check logs
journalctl -u ollama -f
```

### Issue: GPU not detected

```bash
# Check NVIDIA driver
nvidia-smi

# Reinstall CUDA toolkit if needed
sudo apt install nvidia-cuda-toolkit

# Verify PyTorch CUDA
python3 -c "import torch; print(torch.cuda.is_available())"
```

### Issue: Out of memory

```bash
# Reduce model size in .env
OLLAMA_MODEL=qwen2.5:7b

# Or reduce context window in main_offline.py
"num_ctx": 4096,  # Instead of 8192
```

### Issue: Slow embeddings

```bash
# Verify GPU is used for embeddings
python3 << EOF
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
print(model.device)  # Should be 'cuda:0'
EOF

# If CPU, reinstall torch with CUDA:
pip uninstall torch
pip install torch --index-url https://download.pytorch.org/whl/cu121
```

---

## 📊 MONITORING

### Resource Usage

```bash
# GPU monitoring
watch -n 1 nvidia-smi

# System resources
htop

# Disk usage
df -h

# Docker stats
docker stats
```

### Application Logs

```bash
# Real-time logs
tail -f logs/production_trace.log

# Search for errors
grep ERROR logs/production_trace.log

# Monitor response times
grep "Ollama response" logs/production_trace.log | tail -20
```

---

## 🔄 UPDATING THE SYSTEM

### Update Models

```bash
# Pull new Ollama model
ollama pull qwen2.5:latest

# Update .env
OLLAMA_MODEL=qwen2.5:latest

# Restart service
sudo systemctl restart goeic-rag
```

### Update Code

```bash
cd ~/goeic_rag
git pull  # If using git
source venv/bin/activate
pip install -r requirements_offline.txt --upgrade
sudo systemctl restart goeic-rag
```

---

## 💡 TIPS FOR BEST QUALITY

### 1. Prompt Engineering
The professional prompt in `main_offline.py` is preserved from your GPT-4 setup. Don't modify the `build_professional_prompt()` function.

### 2. Context Window
Qwen 2.5 14B supports up to 32K tokens. Adjust if needed:
```python
"num_ctx": 16384,  # In main_offline.py, line 656
```

### 3. Temperature
Lower = more deterministic:
```python
"temperature": 0.1,  # Already optimal
```

### 4. Arabic Text Quality
The multilingual embedding model handles Arabic well. For even better Arabic:
```bash
# Alternative embedding model (larger, better Arabic):
EMBEDDING_MODEL=sentence-transformers/paraphrase-multilingual-mpnet-base-v2
```

---

## 📈 COST SAVINGS

| Component | Old (API) | New (Offline) | Savings |
|-----------|-----------|---------------|---------|
| LLM (GPT-4) | $30-100/day | $0 | 100% |
| Embeddings | $5-20/day | $0 | 100% |
| Voice (Whisper) | $10-30/day | $0 | 100% |
| **TOTAL** | **$45-150/day** | **$0** | **100%** |

**Monthly savings: $1,350 - $4,500** 🎉

---

## 🆘 SUPPORT

If you encounter issues:
1. Check logs: `tail -f logs/production_trace.log`
2. Verify all services: Ollama, Weaviate, GPU
3. Test each component individually
4. Check resource usage: RAM, VRAM, Disk

**Everything is now 100% offline and FREE!** 🚀
